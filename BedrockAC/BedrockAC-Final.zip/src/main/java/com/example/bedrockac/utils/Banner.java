package com.example.bedrockac.utils;

public class Banner {

    public static String getBanner() {
        return "\n" +
                "  ╔═══════════════════════════════════════════════════════╗\n" +
                "  ║                                                       ║\n" +
                "  ║             ██████╗ ███████╗██████╗ ██████╗ ██████╗  ║\n" +
                "  ║             ██╔══██╗██╔════╝██╔══██╗██╔══██╗██╔══██╗ ║\n" +
                "  ║             ██████╔╝█████╗  ██║  ██║██████╔╝██║  ██║ ║\n" +
                "  ║             ██╔══██╗██╔══╝  ██║  ██║██╔══██╗██║  ██║ ║\n" +
                "  ║             ██████╔╝███████╗██████╔╝██║  ██║██████╔╝ ║\n" +
                "  ║             ╚═════╝ ╚══════╝╚═════╝ ╚═╝  ╚═╝╚═════╝  ║\n" +
                "  ║                                                       ║\n" +
                "  ║                    ┌─────────────────┐                ║\n" +
                "  ║                    │  BedrockAC 1.0  │                ║\n" +
                "  ║                    │  Anti-Cheat     │                ║\n" +
                "  ║                    └─────────────────┘                ║\n" +
                "  ║                                                       ║\n" +
                "  ║  Made by Gemini • Minecraft 1.20.4 • Spigot          ║\n" +
                "  ║                                                       ║\n" +
                "  ╚═══════════════════════════════════════════════════════╝\n";
    }

    public static String getChecksBanner() {
        return "\n" +
                "  ╔════════════════════════════════════════════════════╗\n" +
                "  ║           🛡️ Loaded Anti-Cheat Checks 🛡️          ║\n" +
                "  ╠════════════════════════════════════════════════════╣\n" +
                "  ║  ✓ KillAura (A)          - Fast attack detection   ║\n" +
                "  ║  ✓ Reach (A)             - Extended reach check    ║\n" +
                "  ║  ✓ AutoClicker (A)       - Click pattern analysis  ║\n" +
                "  ║  ✓ Velocity (A)          - Knockback manipulation  ║\n" +
                "  ║  ✓ AimAssist (A)         - Aim rotation detection  ║\n" +
                "  ║  ✓ Criticals (A)         - Critical hit analysis   ║\n" +
                "  ║  ✓ FastBow (A)           - Bow charge time check   ║\n" +
                "  ║  ✓ Flight (A)            - Illegal flight detect   ║\n" +
                "  ╚════════════════════════════════════════════════════╝\n";
    }

    public static String getDisableBanner() {
        return "\n" +
                "  ╔════════════════════════════════════════════════════╗\n" +
                "  ║                                                    ║\n" +
                "  ║      🔴 BedrockAC has been disabled 🔴            ║\n" +
                "  ║                                                    ║\n" +
                "  ╚════════════════════════════════════════════════════╝\n";
    }
}
